#ifndef INPUTCMD_H
#define INPUTCMD_H
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int inputCMD(string value);


#endif // INPUTCMD_H
