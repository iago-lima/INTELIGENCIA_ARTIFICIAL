Para executar o programa siga os passos:
1 - Abra o terminal e entre na pasta do arquivo
2 - Execute o comando make
3 - entre na pasta bin 
4 - execute o aplicativo "app" com os seguintes parâmetros
	4.1 - ./app tipo_de_busca origem destino
PS.: Tipo de buscas:
	* bfs (Busca em largura)
	* dfs (Busca em profundidade)
	* ucs (Busca por custo uniforme)
Exemplo:
	$ ./app ucs arad bucharest


